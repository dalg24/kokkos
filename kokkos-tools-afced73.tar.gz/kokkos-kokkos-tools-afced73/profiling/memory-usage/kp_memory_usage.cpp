// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#include <cstdio>
#include <inttypes.h>
#include <vector>
#include <unordered_map>
#include <atomic>
#include <mutex>

#include <sys/resource.h>
#include <unistd.h>

#include "kp_core.hpp"
#include "kp_timer.hpp"

namespace KokkosTools {
namespace MemoryUsage {

char space_name[16][64];

int num_spaces;
std::vector<std::tuple<double, uint64_t, double> > space_size_track[16];
uint64_t space_size[16];

static std::mutex m;

Kokkos::Timer timer;

double max_mem_usage() {
  struct rusage app_info;
  getrusage(RUSAGE_SELF, &app_info);
  const double max_rssKB = app_info.ru_maxrss;
  return max_rssKB * 1024;
}

void kokkosp_init_library(const int /*loadSeq*/,
                          const uint64_t /*interfaceVer*/,
                          const uint32_t /*devInfoCount*/,
                          Kokkos_Profiling_KokkosPDeviceInfo* /*deviceInfo*/) {
  num_spaces = 0;
  for (int i = 0; i < 16; i++) space_size[i] = 0;

  timer.reset();
}

void kokkosp_finalize_library() {
  char* hostname = (char*)malloc(sizeof(char) * 256);
  gethostname(hostname, 256);
  int pid                     = getpid();
  std::string hostname_string = hostname;

  for (int s = 0; s < num_spaces; s++) {
    std::string fileOutput = hostname_string + "-" + std::to_string(pid) + "-" +
                             space_name[s] + ".memspace_usage";

    FILE* ofile = fopen(fileOutput.c_str(), "wb");

    fprintf(ofile, "# Space %s\n", space_name[s]);
    fprintf(ofile,
            "# Time(s)  Size(MB)   HighWater(MB)   HighWater-Process(MB)\n");
    uint64_t maxvalue = 0;
    for (unsigned int i = 0; i < space_size_track[s].size(); i++) {
      if (std::get<1>(space_size_track[s][i]) > maxvalue)
        maxvalue = std::get<1>(space_size_track[s][i]);
      fprintf(ofile, "%lf %.1lf %.1lf %.1lf\n",
              std::get<0>(space_size_track[s][i]),
              1.0 * std::get<1>(space_size_track[s][i]) / 1024 / 1024,
              1.0 * maxvalue / 1024 / 1024,
              1.0 * std::get<2>(space_size_track[s][i]) / 1024 / 1024);
    }
    fclose(ofile);
  }
  free(hostname);
}

void kokkosp_allocate_data(const SpaceHandle space, const char* /*label*/,
                           const void* const /*ptr*/, const uint64_t size) {
  std::lock_guard<std::mutex> lock(m);

  double time = timer.seconds();

  int space_i = num_spaces;
  for (int s = 0; s < num_spaces; s++)
    if (strcmp(space_name[s], space.name) == 0) space_i = s;

  if (space_i == num_spaces) {
    strncpy(space_name[num_spaces], space.name, 64);
    num_spaces++;
  }
  space_size[space_i] += size;
  space_size_track[space_i].push_back(
      std::make_tuple(time, space_size[space_i], max_mem_usage()));
}

void kokkosp_deallocate_data(const SpaceHandle space, const char* /*label*/,
                             const void* const /*ptr*/, const uint64_t size) {
  std::lock_guard<std::mutex> lock(m);

  double time = timer.seconds();

  int space_i = num_spaces;
  for (int s = 0; s < num_spaces; s++)
    if (strcmp(space_name[s], space.name) == 0) space_i = s;

  if (space_i == num_spaces) {
    strncpy(space_name[num_spaces], space.name, 64);
    num_spaces++;
  }
  if (space_size[space_i] >= size) {
    space_size[space_i] -= size;
    space_size_track[space_i].push_back(
        std::make_tuple(time, space_size[space_i], max_mem_usage()));
  }
}

Kokkos::Tools::Experimental::EventSet get_event_set() {
  Kokkos::Tools::Experimental::EventSet my_event_set;
  memset(&my_event_set, 0,
         sizeof(my_event_set));  // zero any pointers not set here
  my_event_set.init            = kokkosp_init_library;
  my_event_set.finalize        = kokkosp_finalize_library;
  my_event_set.allocate_data   = kokkosp_allocate_data;
  my_event_set.deallocate_data = kokkosp_deallocate_data;
  return my_event_set;
}

}  // namespace MemoryUsage
}  // namespace KokkosTools

extern "C" {

namespace impl = KokkosTools::MemoryUsage;

EXPOSE_INIT(impl::kokkosp_init_library)
EXPOSE_FINALIZE(impl::kokkosp_finalize_library)
EXPOSE_ALLOCATE(impl::kokkosp_allocate_data)
EXPOSE_DEALLOCATE(impl::kokkosp_deallocate_data)

}  // extern "C"
