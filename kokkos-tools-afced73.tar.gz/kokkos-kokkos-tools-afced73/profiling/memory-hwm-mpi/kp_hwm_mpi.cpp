// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project
#include <sys/resource.h>
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cinttypes>
#include <mpi.h>

#include "kp_core.hpp"

namespace KokkosTools {
namespace HighwaterMarkMPI {

static int world_rank = 0;
static int world_size = 1;

// darwin report rusage.ru_maxrss in bytes
#if defined(__APPLE__) || defined(__MACH__)
#define RU_MAXRSS_UNITS 1024
#else
#define RU_MAXRSS_UNITS 1
#endif

void kokkosp_init_library(const int loadSeq, const uint64_t interfaceVer,
                          const uint32_t /*devInfoCount*/,
                          Kokkos_Profiling_KokkosPDeviceInfo* /*deviceInfo*/) {
  int mpi_is_initialized;
  MPI_Initialized(&mpi_is_initialized);
  if (!mpi_is_initialized) {
    printf("KokkosP: you must initialize MPI first!\n");
    exit(-1);
  }

  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);

  if (world_rank == 0) {
    printf(
        "KokkosP: High Water Mark Library Initialized (sequence is %d, "
        "version: %" PRIu64 ")\n",
        loadSeq, interfaceVer);
  }
}

void kokkosp_finalize_library() {
  if (world_rank == 0) {
    printf("\n");
    printf("KokkosP: Finalization of profiling library.\n");
  }

  struct rusage sys_resources;
  getrusage(RUSAGE_SELF, &sys_resources);
  long hwm = sys_resources.ru_maxrss * RU_MAXRSS_UNITS;

  // Max
  long hwm_max;
  MPI_Reduce(&hwm, &hwm_max, 1, MPI_LONG, MPI_MAX, 0, MPI_COMM_WORLD);

  // Min
  long hwm_min;
  MPI_Reduce(&hwm, &hwm_min, 1, MPI_LONG, MPI_MIN, 0, MPI_COMM_WORLD);

  // Average
  long hwm_ave;
  MPI_Reduce(&hwm, &hwm_ave, 1, MPI_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
  hwm_ave /= world_size;

  if (world_rank == 0) {
    printf("KokkosP: High water mark memory consumption: %ld kB\n", hwm_max);
    printf("  Max: %ld, Min: %ld, Ave: %ld kB\n", hwm_max, hwm_min, hwm_ave);
    printf("\n");
  }
}

Kokkos::Tools::Experimental::EventSet get_event_set() {
  Kokkos::Tools::Experimental::EventSet my_event_set;
  memset(&my_event_set, 0,
         sizeof(my_event_set));  // zero any pointers not set here
  my_event_set.init     = kokkosp_init_library;
  my_event_set.finalize = kokkosp_finalize_library;
  return my_event_set;
}

}  // namespace HighwaterMarkMPI
}  // namespace KokkosTools

extern "C" {

namespace impl = KokkosTools::HighwaterMarkMPI;

EXPOSE_INIT(impl::kokkosp_init_library)
EXPOSE_FINALIZE(impl::kokkosp_finalize_library)

}  // extern "C"
