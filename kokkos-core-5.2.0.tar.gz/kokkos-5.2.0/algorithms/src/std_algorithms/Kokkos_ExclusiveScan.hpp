// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_STD_ALGORITHMS_EXCLUSIVE_SCAN_HPP
#define KOKKOS_STD_ALGORITHMS_EXCLUSIVE_SCAN_HPP

#include "impl/Kokkos_ExclusiveScan.hpp"
#include <Kokkos_Iterator.hpp>

namespace Kokkos {
namespace Experimental {

//
// overload set accepting execution space
//

// overload set 1
template <typename ExecutionSpace, typename InputIteratorType,
          typename OutputIteratorType, typename ValueType,
          std::enable_if_t<
              Impl::are_iterators_v<InputIteratorType, OutputIteratorType>&& ::
                  Kokkos::is_execution_space_v<ExecutionSpace>,
              int> = 0>
OutputIteratorType exclusive_scan(const ExecutionSpace& ex,
                                  InputIteratorType first,
                                  InputIteratorType last,
                                  OutputIteratorType first_dest,
                                  ValueType init_value) {
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  using binary_op = Impl::StdExclusiveScanDefaultJoinFunctor<ValueType>;

  return Impl::exclusive_scan_exespace_impl(
      "Kokkos::exclusive_scan_default_functors_iterator_api", ex, first, last,
      first_dest, std::move(init_value), binary_op());
}

template <typename ExecutionSpace, typename InputIteratorType,
          typename OutputIteratorType, typename ValueType,
          std::enable_if_t<
              Impl::are_iterators_v<InputIteratorType, OutputIteratorType>&& ::
                  Kokkos::is_execution_space_v<ExecutionSpace>,
              int> = 0>
OutputIteratorType exclusive_scan(const std::string& label,
                                  const ExecutionSpace& ex,
                                  InputIteratorType first,
                                  InputIteratorType last,
                                  OutputIteratorType first_dest,
                                  ValueType init_value) {
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  using binary_op = Impl::StdExclusiveScanDefaultJoinFunctor<ValueType>;

  return Impl::exclusive_scan_exespace_impl(label, ex, first, last, first_dest,
                                            std::move(init_value), binary_op());
}

template <
    typename ExecutionSpace, typename DataType1, typename... Properties1,
    typename DataType2, typename... Properties2, typename ValueType,
    std::enable_if_t<::Kokkos::is_execution_space_v<ExecutionSpace>, int> = 0>
auto exclusive_scan(const ExecutionSpace& ex,
                    const ::Kokkos::View<DataType1, Properties1...>& view_from,
                    const ::Kokkos::View<DataType2, Properties2...>& view_dest,
                    ValueType init_value) {
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_from);
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_dest);
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  Impl::expect_less_or_equal_extents(view_from, view_dest);
  using binary_op = Impl::StdExclusiveScanDefaultJoinFunctor<ValueType>;

  namespace KE = ::Kokkos::Experimental;
  return Impl::exclusive_scan_exespace_impl(
      "Kokkos::exclusive_scan_default_functors_view_api", ex,
      KE::cbegin(view_from), KE::cend(view_from), KE::begin(view_dest),
      std::move(init_value), binary_op());
}

template <
    typename ExecutionSpace, typename DataType1, typename... Properties1,
    typename DataType2, typename... Properties2, typename ValueType,
    std::enable_if_t<::Kokkos::is_execution_space_v<ExecutionSpace>, int> = 0>
auto exclusive_scan(const std::string& label, const ExecutionSpace& ex,
                    const ::Kokkos::View<DataType1, Properties1...>& view_from,
                    const ::Kokkos::View<DataType2, Properties2...>& view_dest,
                    ValueType init_value) {
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_from);
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_dest);
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  Impl::expect_less_or_equal_extents(view_from, view_dest);
  using binary_op = Impl::StdExclusiveScanDefaultJoinFunctor<ValueType>;

  namespace KE = ::Kokkos::Experimental;
  return Impl::exclusive_scan_exespace_impl(
      label, ex, KE::cbegin(view_from), KE::cend(view_from),
      KE::begin(view_dest), std::move(init_value), binary_op());
}

// overload set 2
template <typename ExecutionSpace, typename InputIteratorType,
          typename OutputIteratorType, typename ValueType,
          typename BinaryOpType,
          std::enable_if_t<
              Impl::are_iterators_v<InputIteratorType, OutputIteratorType>&& ::
                  Kokkos::is_execution_space_v<ExecutionSpace>,
              int> = 0>
OutputIteratorType exclusive_scan(const ExecutionSpace& ex,
                                  InputIteratorType first,
                                  InputIteratorType last,
                                  OutputIteratorType first_dest,
                                  ValueType init_value, BinaryOpType bop) {
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  return Impl::exclusive_scan_exespace_impl(
      "Kokkos::exclusive_scan_custom_functors_iterator_api", ex, first, last,
      first_dest, std::move(init_value), bop);
}

template <typename ExecutionSpace, typename InputIteratorType,
          typename OutputIteratorType, typename ValueType,
          typename BinaryOpType,
          std::enable_if_t<
              Impl::are_iterators_v<InputIteratorType, OutputIteratorType>&& ::
                  Kokkos::is_execution_space_v<ExecutionSpace>,
              int> = 0>
OutputIteratorType exclusive_scan(const std::string& label,
                                  const ExecutionSpace& ex,
                                  InputIteratorType first,
                                  InputIteratorType last,
                                  OutputIteratorType first_dest,
                                  ValueType init_value, BinaryOpType bop) {
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  return Impl::exclusive_scan_exespace_impl(label, ex, first, last, first_dest,
                                            std::move(init_value), bop);
}

template <
    typename ExecutionSpace, typename DataType1, typename... Properties1,
    typename DataType2, typename... Properties2, typename ValueType,
    typename BinaryOpType,
    std::enable_if_t<::Kokkos::is_execution_space_v<ExecutionSpace>, int> = 0>
auto exclusive_scan(const ExecutionSpace& ex,
                    const ::Kokkos::View<DataType1, Properties1...>& view_from,
                    const ::Kokkos::View<DataType2, Properties2...>& view_dest,
                    ValueType init_value, BinaryOpType bop) {
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_from);
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_dest);
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");

  Impl::expect_less_or_equal_extents(view_from, view_dest);
  namespace KE = ::Kokkos::Experimental;
  return Impl::exclusive_scan_exespace_impl(
      "Kokkos::exclusive_scan_custom_functors_view_api", ex,
      KE::cbegin(view_from), KE::cend(view_from), KE::begin(view_dest),
      std::move(init_value), bop);
}

template <
    typename ExecutionSpace, typename DataType1, typename... Properties1,
    typename DataType2, typename... Properties2, typename ValueType,
    typename BinaryOpType,
    std::enable_if_t<::Kokkos::is_execution_space_v<ExecutionSpace>, int> = 0>
auto exclusive_scan(const std::string& label, const ExecutionSpace& ex,
                    const ::Kokkos::View<DataType1, Properties1...>& view_from,
                    const ::Kokkos::View<DataType2, Properties2...>& view_dest,
                    ValueType init_value, BinaryOpType bop) {
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_from);
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_dest);
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");

  Impl::expect_less_or_equal_extents(view_from, view_dest);
  namespace KE = ::Kokkos::Experimental;
  return Impl::exclusive_scan_exespace_impl(
      label, ex, KE::cbegin(view_from), KE::cend(view_from),
      KE::begin(view_dest), std::move(init_value), bop);
}

//
// overload set accepting a team handle
// Note: for now omit the overloads accepting a label
// since they cause issues on device because of the string allocation.
//

// overload set 1
template <typename TeamHandleType, typename InputIteratorType,
          typename OutputIteratorType, typename ValueType,
          std::enable_if_t<
              Impl::are_iterators_v<InputIteratorType, OutputIteratorType> &&
                  Kokkos::is_team_handle_v<TeamHandleType>,
              int> = 0>
KOKKOS_FUNCTION OutputIteratorType
exclusive_scan(const TeamHandleType& teamHandle, InputIteratorType first,
               InputIteratorType last, OutputIteratorType first_dest,
               ValueType init_value) {
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  return Impl::exclusive_scan_default_op_team_impl(
      teamHandle, first, last, first_dest, std::move(init_value));
}

template <typename TeamHandleType, typename DataType1, typename... Properties1,
          typename DataType2, typename... Properties2, typename ValueType,
          std::enable_if_t<::Kokkos::is_team_handle_v<TeamHandleType>, int> = 0>
KOKKOS_FUNCTION auto exclusive_scan(
    const TeamHandleType& teamHandle,
    const ::Kokkos::View<DataType1, Properties1...>& view_from,
    const ::Kokkos::View<DataType2, Properties2...>& view_dest,
    ValueType init_value) {
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_from);
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_dest);
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");

  Impl::expect_less_or_equal_extents(view_from, view_dest);
  namespace KE = ::Kokkos::Experimental;
  return Impl::exclusive_scan_default_op_team_impl(
      teamHandle, KE::cbegin(view_from), KE::cend(view_from),
      KE::begin(view_dest), std::move(init_value));
}

// overload set 2
template <typename TeamHandleType, typename InputIteratorType,
          typename OutputIteratorType, typename ValueType,
          typename BinaryOpType,
          std::enable_if_t<
              Impl::are_iterators_v<InputIteratorType, OutputIteratorType> &&
                  Kokkos::is_team_handle_v<TeamHandleType>,
              int> = 0>
KOKKOS_FUNCTION OutputIteratorType
exclusive_scan(const TeamHandleType& teamHandle, InputIteratorType first,
               InputIteratorType last, OutputIteratorType first_dest,
               ValueType init_value, BinaryOpType bop) {
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");
  return Impl::exclusive_scan_custom_op_team_impl(
      teamHandle, first, last, first_dest, std::move(init_value), bop);
}

template <typename TeamHandleType, typename DataType1, typename... Properties1,
          typename DataType2, typename... Properties2, typename ValueType,
          typename BinaryOpType,
          std::enable_if_t<::Kokkos::is_team_handle_v<TeamHandleType>, int> = 0>
KOKKOS_FUNCTION auto exclusive_scan(
    const TeamHandleType& teamHandle,
    const ::Kokkos::View<DataType1, Properties1...>& view_from,
    const ::Kokkos::View<DataType2, Properties2...>& view_dest,
    ValueType init_value, BinaryOpType bop) {
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_from);
  Impl::static_assert_is_admissible_to_kokkos_std_algorithms(view_dest);
  static_assert(std::is_move_constructible_v<ValueType>,
                "ValueType must be move constructible.");

  Impl::expect_less_or_equal_extents(view_from, view_dest);
  namespace KE = ::Kokkos::Experimental;
  return Impl::exclusive_scan_custom_op_team_impl(
      teamHandle, KE::cbegin(view_from), KE::cend(view_from),
      KE::begin(view_dest), std::move(init_value), bop);
}

}  // namespace Experimental
}  // namespace Kokkos

#endif
