// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_STD_ALGORITHMS_FOR_EACH_IMPL_HPP
#define KOKKOS_STD_ALGORITHMS_FOR_EACH_IMPL_HPP

#include <Kokkos_Macros.hpp>
#ifdef KOKKOS_ENABLE_EXPERIMENTAL_CXX20_MODULES
import kokkos.core;
#else
#include <Kokkos_Core.hpp>
#endif
#include "Kokkos_Constraints.hpp"
#include "Kokkos_HelperPredicates.hpp"
#include <string>

namespace Kokkos {
namespace Experimental {
namespace Impl {

template <class IteratorType, class UnaryFunctorType>
struct StdForEachFunctor {
  using index_type = typename IteratorType::difference_type;
  IteratorType m_first;
  UnaryFunctorType m_functor;

  KOKKOS_FUNCTION
  void operator()(index_type i) const { m_functor(m_first[i]); }

  KOKKOS_FUNCTION
  StdForEachFunctor(IteratorType _first, UnaryFunctorType _functor)
      : m_first(std::move(_first)), m_functor(std::move(_functor)) {}
};

template <class HandleType, class IteratorType, class UnaryFunctorType>
void for_each_exespace_impl(const std::string& label, const HandleType& handle,
                            IteratorType first, IteratorType last,
                            UnaryFunctorType functor) {
  // checks
  Impl::static_assert_random_access_and_accessible(handle, first);
  Impl::expect_valid_range(first, last);

  // run
  const auto num_elements = Kokkos::Experimental::distance(first, last);
  ::Kokkos::parallel_for(
      label, RangePolicy<HandleType>(handle, 0, num_elements),
      StdForEachFunctor<IteratorType, UnaryFunctorType>(first, functor));
  handle.fence("Kokkos::for_each: fence after operation");
}

template <class ExecutionSpace, class IteratorType, class SizeType,
          class UnaryFunctorType>
IteratorType for_each_n_exespace_impl(const std::string& label,
                                      const ExecutionSpace& ex,
                                      IteratorType first, SizeType n,
                                      UnaryFunctorType functor) {
  auto last = first + n;
  Impl::static_assert_random_access_and_accessible(ex, first, last);
  Impl::expect_valid_range(first, last);

  if (n == 0) {
    return first;
  }

  for_each_exespace_impl(label, ex, first, last, std::move(functor));
  // no need to fence since for_each_exespace_impl fences already

  return last;
}

//
// team impl
//
template <class TeamHandleType, class IteratorType, class UnaryFunctorType>
KOKKOS_FUNCTION void for_each_team_impl(const TeamHandleType& teamHandle,
                                        IteratorType first, IteratorType last,
                                        UnaryFunctorType functor) {
  // checks
  Impl::static_assert_random_access_and_accessible(teamHandle, first);
  Impl::expect_valid_range(first, last);
  // run
  const auto num_elements = Kokkos::Experimental::distance(first, last);
  ::Kokkos::parallel_for(
      TeamThreadRange(teamHandle, 0, num_elements),
      StdForEachFunctor<IteratorType, UnaryFunctorType>(first, functor));
  teamHandle.team_barrier();
}

template <class TeamHandleType, class IteratorType, class SizeType,
          class UnaryFunctorType>
KOKKOS_FUNCTION IteratorType
for_each_n_team_impl(const TeamHandleType& teamHandle, IteratorType first,
                     SizeType n, UnaryFunctorType functor) {
  auto last = first + n;
  Impl::static_assert_random_access_and_accessible(teamHandle, first, last);
  Impl::expect_valid_range(first, last);

  if (n == 0) {
    return first;
  }

  for_each_team_impl(teamHandle, first, last, std::move(functor));
  // no need to fence since for_each_team_impl fences already

  return last;
}

}  // namespace Impl
}  // namespace Experimental
}  // namespace Kokkos

#endif
