// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#ifndef KOKKOS_STD_ALGORITHMS_ADJACENT_DIFFERENCE_IMPL_HPP
#define KOKKOS_STD_ALGORITHMS_ADJACENT_DIFFERENCE_IMPL_HPP

#include <Kokkos_Macros.hpp>
#ifdef KOKKOS_ENABLE_EXPERIMENTAL_CXX20_MODULES
import kokkos.core;
#else
#include <Kokkos_Core.hpp>
#endif
#include "Kokkos_Constraints.hpp"
#include "Kokkos_HelperPredicates.hpp"
#include <string>

namespace Kokkos {
namespace Experimental {
namespace Impl {

template <class ValueType1, class ValueType2, class RetType = ValueType2>
struct StdAdjacentDifferenceDefaultBinaryOpFunctor {
  KOKKOS_FUNCTION
  constexpr RetType operator()(const ValueType1& a, const ValueType2& b) const {
    return a - b;
  }
};

template <class InputIteratorType, class OutputIteratorType,
          class BinaryOperator>
struct StdAdjacentDiffFunctor {
  using index_type = typename InputIteratorType::difference_type;

  const InputIteratorType m_first_from;
  const OutputIteratorType m_first_dest;
  BinaryOperator m_op;

  KOKKOS_FUNCTION
  void operator()(const index_type i) const {
    const auto& my_value = m_first_from[i];
    if (i == 0) {
      m_first_dest[i] = my_value;
    } else {
      const auto& left_value = m_first_from[i - 1];
      m_first_dest[i]        = m_op(my_value, left_value);
    }
  }

  KOKKOS_FUNCTION
  StdAdjacentDiffFunctor(InputIteratorType first_from,
                         OutputIteratorType first_dest, BinaryOperator op)
      : m_first_from(std::move(first_from)),
        m_first_dest(std::move(first_dest)),
        m_op(std::move(op)) {}
};

//
// exespace impl
//
template <class ExecutionSpace, class InputIteratorType,
          class OutputIteratorType, class BinaryOp>
OutputIteratorType adjacent_difference_exespace_impl(
    const std::string& label, const ExecutionSpace& ex,
    InputIteratorType first_from, InputIteratorType last_from,
    OutputIteratorType first_dest, BinaryOp bin_op) {
  // checks
  Impl::static_assert_random_access_and_accessible(ex, first_from, first_dest);
  Impl::static_assert_iterators_have_matching_difference_type(first_from,
                                                              first_dest);
  Impl::expect_valid_range(first_from, last_from);

  if (first_from == last_from) {
    return first_dest;
  }

#ifdef KOKKOS_ENABLE_DEBUG
  // check for overlapping iterators
  Impl::expect_no_overlap(first_from, last_from, first_dest);
#endif

  // run
  const auto num_elements =
      Kokkos::Experimental::distance(first_from, last_from);
  ::Kokkos::parallel_for(
      label, RangePolicy<ExecutionSpace>(ex, 0, num_elements),
      StdAdjacentDiffFunctor(first_from, first_dest, bin_op));
  ex.fence("Kokkos::adjacent_difference: fence after operation");

  // return
  return first_dest + num_elements;
}

//
// team impl
//
template <class TeamHandleType, class InputIteratorType,
          class OutputIteratorType, class BinaryOp>
KOKKOS_FUNCTION OutputIteratorType adjacent_difference_team_impl(
    const TeamHandleType& teamHandle, InputIteratorType first_from,
    InputIteratorType last_from, OutputIteratorType first_dest,
    BinaryOp bin_op) {
  // checks
  Impl::static_assert_random_access_and_accessible(teamHandle, first_from,
                                                   first_dest);
  Impl::static_assert_iterators_have_matching_difference_type(first_from,
                                                              first_dest);
  Impl::expect_valid_range(first_from, last_from);

  if (first_from == last_from) {
    return first_dest;
  }

#ifdef KOKKOS_ENABLE_DEBUG
  // check for overlapping iterators
  Impl::expect_no_overlap(first_from, last_from, first_dest);
#endif

  // run
  const auto num_elements =
      Kokkos::Experimental::distance(first_from, last_from);
  ::Kokkos::parallel_for(
      TeamThreadRange(teamHandle, 0, num_elements),
      StdAdjacentDiffFunctor(first_from, first_dest, bin_op));
  teamHandle.team_barrier();

  // return
  return first_dest + num_elements;
}

}  // namespace Impl
}  // namespace Experimental
}  // namespace Kokkos

#endif
