// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project

#include <Kokkos_Macros.hpp>

#include <gtest/gtest.h>

#include <Kokkos_Macros.hpp>
#ifdef KOKKOS_ENABLE_EXPERIMENTAL_CXX20_MODULES
import kokkos.core;
import kokkos.unordered_map;
#else
#include <Kokkos_Core.hpp>
#include <Kokkos_UnorderedMap.hpp>
#endif

#include <TestGlobal2LocalIds.hpp>
#include <TestUnorderedMapPerformance.hpp>

#include <TestDynRankView.hpp>
#include <TestScatterView.hpp>
#include <TestDualView.hpp>

#include <iomanip>
#include <sstream>
#include <string>
#include <fstream>

namespace Performance {

TEST(hpx, dynrankview_perf) {
  std::cout << "HPX" << std::endl;
  std::cout << " DynRankView vs View: Initialization Only " << std::endl;
  test_dynrankview_op_perf<Kokkos::Experimental::HPX>(8192);
}

TEST(hpx, dualview_perf) {
  std::cout << "HPX" << std::endl;
  std::cout << " DualView Access Performance " << std::endl;
  test_dualview<size_t, Kokkos::Experimental::HPX>();
}

TEST(hpx, global_2_local) {
  std::cout << "HPX" << std::endl;
  std::cout << "size, create, generate, fill, find" << std::endl;
  for (unsigned i = Performance::begin_id_size; i <= Performance::end_id_size;
       i *= Performance::id_step)
    test_global_to_local_ids<Kokkos::Experimental::HPX>(i);
}

TEST(hpx, unordered_map_performance_near) {
  unsigned num_hpx = 4;
  std::ostringstream base_file_name;
  base_file_name << "hpx-" << num_hpx << "-near";
  Perf::run_performance_tests<Kokkos::Experimental::HPX, true>(
      base_file_name.str());
}

TEST(hpx, unordered_map_performance_far) {
  unsigned num_hpx = 4;
  std::ostringstream base_file_name;
  base_file_name << "hpx-" << num_hpx << "-far";
  Perf::run_performance_tests<Kokkos::Experimental::HPX, false>(
      base_file_name.str());
}

TEST(hpx, scatter_view) {
  std::cout << "ScatterView data-duplicated test:\n";
  Perf::test_scatter_view<Kokkos::Experimental::HPX, Kokkos::LayoutRight,
                          Kokkos::Experimental::ScatterDuplicated,
                          Kokkos::Experimental::ScatterNonAtomic>(10,
                                                                  1000 * 1000);
  // std::cout << "ScatterView atomics test:\n";
  // Perf::test_scatter_view<Kokkos::Experimental::HPX, Kokkos::LayoutRight,
  //  Kokkos::Experimental::ScatterNonDuplicated,
  //  Kokkos::Experimental::ScatterAtomic>(10, 1000 * 1000);
}

}  // namespace Performance
