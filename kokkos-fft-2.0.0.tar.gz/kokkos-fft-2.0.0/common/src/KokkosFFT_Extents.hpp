// SPDX-FileCopyrightText: (C) The Kokkos-FFT development team, see COPYRIGHT.md file
//
// SPDX-License-Identifier: MIT OR Apache-2.0 WITH LLVM-exception

#ifndef KOKKOSFFT_EXTENTS_HPP
#define KOKKOSFFT_EXTENTS_HPP

#include <algorithm>
#include <numeric>
#include <tuple>
#include <utility>
#include <vector>
#include <Kokkos_Core.hpp>
#include "KokkosFFT_Asserts.hpp"
#include "KokkosFFT_CheckConditions.hpp"
#include "KokkosFFT_Common_Types.hpp"
#include "KokkosFFT_Container_Helpers.hpp"
#include "KokkosFFT_Convert_Types.hpp"
#include "KokkosFFT_Mapping.hpp"
#include "KokkosFFT_Traits.hpp"

namespace KokkosFFT {
namespace Impl {
/// \brief Compute the extent after FFT
/// For real to complex case, the output extent is
/// out_extent = in_extent / 2 + 1
/// For complex to complex case, the output extent is
/// out_extent = in_extent
///
/// \param[in] extent The input extent
/// \param[in] is_R2C Whether it is real to complex or not
/// \return The output extent
inline auto extent_after_transform(std::size_t extent, bool is_R2C) {
  return is_R2C ? (extent / 2 + 1) : extent;
}

/// \brief Return the extents of the input view
/// \tparam ViewType The type of the input view
///
/// \param[in] view The input view
/// \return The extents of the input view
template <typename ViewType>
auto extract_extents(const ViewType& view) {
  static_assert(Kokkos::is_view_v<ViewType>,
                "extract_extents: ViewType is not a Kokkos::View.");
  constexpr std::size_t rank = ViewType::rank();
  std::array<std::size_t, rank> extents{};
  for (std::size_t i = 0; i < rank; i++) {
    extents.at(i) = view.extent(i);
  }
  return extents;
}

/// \brief Helper to compute strides from extents.
/// The extents are computed from a LayoutRight View.
/// The computed strides can be considered as view strides
/// in the reversed order.
///
/// Examples:
/// v0 (n0) -> (v0.stride(0)) or (1)
/// v1 (n0, n1) -> (v1.stride(1), v1.stride(0)) or (1, n1)
/// v2 (n0, n1, n2) -> (v2.stride(2), v2.stride(1), v2.stride(0))
///                 or (1, n2, n2 * n1)
/// \tparam ContainerType The container type, must be either one of std::array
/// or std::vector
/// \param[in] extents The extents of the data
/// \return strides computed from the input data
/// \throws runtime_error if extents is empty or if any of the extents is less
/// than or equal to 0
template <typename ContainerType,
          std::enable_if_t<is_std_vector_v<ContainerType> ||
                               is_std_array_v<ContainerType>,
                           std::nullptr_t> = nullptr>
auto compute_strides(const ContainerType& extents) {
  using index_type = std::remove_cv_t<
      std::remove_reference_t<typename ContainerType::value_type>>;
  static_assert(std::is_integral_v<index_type>,
                "compute_strides: index_type must be an integral type.");
  KOKKOSFFT_THROW_IF(extents.size() == 0,
                     "extents must have at least one dimension.");
  KOKKOSFFT_THROW_IF(std::any_of(extents.begin(), extents.end(),
                                 [](index_type extent) { return extent <= 0; }),
                     "extents must be greater than 0");
  ContainerType strides = extents, reversed_extents = extents;
  std::reverse(reversed_extents.begin(), reversed_extents.end());

  strides.at(0) = 1;
  for (std::size_t i = 1; i < extents.size(); i++) {
    strides.at(i) = reversed_extents.at(i - 1) * strides.at(i - 1);
  }
  return strides;
}

/// \brief Return a new shape of the input view based on the
/// specified input shape and axes.
///
/// \tparam InViewType The input view type
/// \tparam OutViewType The output view type
/// \tparam DIM         The dimensionality of the shape and axes
///
/// \param in [in] Input view from which to derive the new shape
/// \param out [in] Output view (unused but necessary for type deduction)
/// \param shape [in] The new shape of the input view. If the shape is zero,
/// no modifications are made.
/// \param axes [in] Axes over which the shape modification is applied.
template <typename InViewType, typename OutViewType, std::size_t DIM>
auto get_modified_shape(const InViewType in, const OutViewType /* out */,
                        shape_type<DIM> shape, axis_type<DIM> axes) {
  static_assert(
      KokkosFFT::Impl::have_same_rank_v<InViewType, OutViewType>,
      "get_modified_shape: Input View and Output View must have the same rank");
  KOKKOSFFT_THROW_IF(!KokkosFFT::Impl::are_valid_axes(in, axes),
                     "input axes are not valid for the view");

  shape_type<DIM> zeros{};  // default shape means no crop or pad
  if (shape == zeros) {
    return extract_extents(in);
  }

  // Convert the input axes to be in the range of [0, rank-1]
  constexpr std::size_t rank = InViewType::rank();
  auto non_negative_axes     = convert_negative_axes(axes, rank);

  using full_shape_type          = shape_type<rank>;
  full_shape_type modified_shape = extract_extents(in);

  // Update shapes based on newly given shape
  for (std::size_t i = 0; i < DIM; i++) {
    auto non_negative_axis = non_negative_axes.at(i);
    KOKKOSFFT_THROW_IF(shape.at(i) <= 0,
                       "get_modified_shape: shape must be greater than 0");
    modified_shape.at(non_negative_axis) = shape.at(i);
  }

  using in_value_type  = typename InViewType::non_const_value_type;
  using out_value_type = typename OutViewType::non_const_value_type;

  bool is_C2R = is_complex_v<in_value_type> && is_real_v<out_value_type>;

  if (is_C2R) {
    auto reshaped_axis               = non_negative_axes.back();
    modified_shape.at(reshaped_axis) = modified_shape.at(reshaped_axis) / 2 + 1;
  }

  return modified_shape;
}

/// \brief Compute padded extents from the extents in Fourier space
///
/// Example, if the first FFT dimension is the 2nd dimension
/// in extents (real): (8, 7, 8)
/// out extents (complex): (8, 7, 5)
/// axes: (0, 1, 2)
/// FFT is operated from 2nd axis, so we have
/// padded extents (real): (8, 7, 10)
///
/// if ValueType is complex, then just return extents
///
/// \tparam ValueType The type used to determine whether padding is required;
/// real types are padded, while complex types return extents unchanged
/// \tparam iType The integer type used for extents
/// \tparam DIM The number of dimensions of the extents
/// \tparam FFT_DIM The number of dimensions of the FFT
///
/// \param[in] extents Extents to be padded if ValueType is real
/// \param[in] axes Axes of the transform
/// \return Padded extents if ValueType is real, otherwise returns extents
/// unchanged
template <typename ValueType, typename iType, std::size_t DIM,
          std::size_t FFT_DIM>
auto compute_padded_extents(const std::array<iType, DIM>& extents,
                            const std::array<iType, FFT_DIM>& axes) {
  static_assert(std::is_integral_v<iType>,
                "compute_padded_extents: iType must be an integral type");
  static_assert(
      FFT_DIM >= 1 && FFT_DIM <= KokkosFFT::MAX_FFT_DIM,
      "compute_padded_extents: the Rank of FFT axes must be between 1 and 3");
  static_assert(
      DIM >= FFT_DIM,
      "compute_padded_extents: View rank must be larger than or equal to "
      "the Rank of FFT axes");

  if constexpr (is_complex_v<ValueType>) return extents;

  std::array<iType, DIM> padded_extents = extents;
  auto last_axis                        = axes.back();
  padded_extents.at(last_axis) *= 2;

  return padded_extents;
}

/// \brief Calculate the permuted extents based on the map
///
/// Example
/// View extents: (n0, n1, n2, n3)
/// map: (0, 2, 3, 1)
/// Next extents: (n0, n2, n3, n1)
///
/// \tparam ContainerType The container type
/// \tparam iType The integer type used for extents
/// \tparam DIM The number of dimensions of the extents.
///
/// \param[in] extents Extents of the View.
/// \param[in] map A map representing how the data is permuted
/// \return A extents of the permuted view
/// \throws std::runtime_error if the size of map is not equal to DIM
/// or if map has duplicate values or if map has values out of the range
/// [0, DIM)
template <typename ContainerType, typename iType, std::size_t DIM>
auto compute_mapped_extents(const std::array<iType, DIM>& extents,
                            const ContainerType& map) {
  using value_type = std::remove_cv_t<
      std::remove_reference_t<typename ContainerType::value_type>>;
  static_assert(std::is_integral_v<value_type>,
                "compute_mapped_extents: Map container value type must be an "
                "integral type");
  KOKKOSFFT_THROW_IF(map.size() != DIM,
                     "extents size must be equal to map size.");
  KOKKOSFFT_THROW_IF(has_duplicate_values(map),
                     "map must not have duplicate values.");

  auto safe_permute = [&extents](const value_type& mapped_idx) -> iType {
    if constexpr (std::is_signed_v<value_type>) {
      KOKKOSFFT_THROW_IF(mapped_idx < 0, "map entries must be in [0, DIM)");
    }
    auto non_negative_mapped_idx = static_cast<std::size_t>(mapped_idx);
    KOKKOSFFT_THROW_IF(non_negative_mapped_idx >= DIM,
                       "map entries must be in [0, DIM)");
    return extents.at(non_negative_mapped_idx);
  };
  std::array<iType, DIM> mapped_extents{};
  std::transform(map.begin(), map.end(), mapped_extents.begin(), safe_permute);

  return mapped_extents;
}

/// \brief Compute input, output and fft extents required for FFT
/// libraries based on the input view, output view, axes and shape.
/// Extents are converted into Layout Right
///
/// \tparam InViewType The input view type
/// \tparam OutViewType The output view type
///
/// \param[in] in Input view
/// \param[in] out Output view
/// \param[in] map mapping for permutation
/// \param[in] axes Axes over which the FFT operations are performed
/// \param[in] modified_in_shape The new shape of the input view
/// \param[in] is_inplace Whether the FFT is inplace or not
template <typename InViewType, typename OutViewType>
auto get_extents(const InViewType& in, const OutViewType& out,
                 const std::vector<int>& map,
                 [[maybe_unused]] const std::vector<int>& axes,
                 const std::vector<std::size_t>& modified_in_shape,
                 [[maybe_unused]] bool is_inplace) {
  using in_value_type     = typename InViewType::non_const_value_type;
  using out_value_type    = typename OutViewType::non_const_value_type;
  using array_layout_type = typename InViewType::array_layout;

  static_assert(!(is_real_v<in_value_type> && is_real_v<out_value_type>),
                "get_extents: real to real transform is not supported");

  constexpr std::size_t rank = InViewType::rank;
  [[maybe_unused]] std::size_t inner_most_axis =
      std::is_same_v<array_layout_type, typename Kokkos::LayoutLeft>
          ? 0
          : (rank - 1);

  // Get extents for the inner most axes in LayoutRight
  // If we allow the FFT on the layoutLeft, this part should be modified
  std::vector<std::size_t> in_extents_full, out_extents_full, fft_extents_full;
  for (std::size_t i = 0; i < rank; i++) {
    auto idx        = map.at(i);
    auto in_extent  = modified_in_shape.at(idx);
    auto out_extent = out.extent(idx);
    in_extents_full.push_back(in_extent);
    out_extents_full.push_back(out_extent);

    // The extent for transform is always equal to the extent
    // of the extent of real type (R2C or C2R)
    // For C2C, the in and out extents are the same.
    // In the end, we can just use the largest extent among in and out extents.
    auto fft_extent = std::max(in_extent, out_extent);
    fft_extents_full.push_back(fft_extent);
  }

  auto mismatched_extents = [&in, &out, &axes]() -> std::string {
    std::string message =
        container_to_string(in.label(), extract_extents(in)) + ", ";
    message += container_to_string(out.label(), extract_extents(out));
    message += ", with ";
    message += container_to_string("axes ", axes);
    return message;
  };

  for (std::size_t i = 0; i < rank; i++) {
    // The requirement for inner_most_axis is different for transform type
    if (i == inner_most_axis) continue;
    KOKKOSFFT_THROW_IF(in_extents_full.at(i) != out_extents_full.at(i),
                       "input and output extents must be the same except for "
                       "the transform axis: " +
                           mismatched_extents());
  }

  if constexpr (is_complex_v<in_value_type> && is_complex_v<out_value_type>) {
    // Then C2C
    KOKKOSFFT_THROW_IF(
        in_extents_full.at(inner_most_axis) !=
            out_extents_full.at(inner_most_axis),
        "input and output extents must be the same for C2C transform: " +
            mismatched_extents());
  }

  if constexpr (is_real_v<in_value_type>) {
    // Then R2C
    if (is_inplace) {
      in_extents_full.at(inner_most_axis) =
          out_extents_full.at(inner_most_axis) * 2;
    } else {
      KOKKOSFFT_THROW_IF(
          out_extents_full.at(inner_most_axis) !=
              in_extents_full.at(inner_most_axis) / 2 + 1,
          "For R2C, the 'output extent' of transform must be equal to "
          "'input extent'/2 + 1: " +
              mismatched_extents());
    }
  }

  if constexpr (is_real_v<out_value_type>) {
    // Then C2R
    if (is_inplace) {
      out_extents_full.at(inner_most_axis) =
          in_extents_full.at(inner_most_axis) * 2;
    } else {
      KOKKOSFFT_THROW_IF(
          in_extents_full.at(inner_most_axis) !=
              out_extents_full.at(inner_most_axis) / 2 + 1,
          "For C2R, the 'input extent' of transform must be equal to "
          "'output extent' / 2 + 1: " +
              mismatched_extents());
    }
  }

  if constexpr (std::is_same_v<array_layout_type, Kokkos::LayoutLeft>) {
    std::reverse(in_extents_full.begin(), in_extents_full.end());
    std::reverse(out_extents_full.begin(), out_extents_full.end());
    std::reverse(fft_extents_full.begin(), fft_extents_full.end());
  }

  // Define subvectors starting from last - DIM
  // Dimensions relevant to FFTs
  const std::size_t DIM = axes.size();
  KOKKOSFFT_THROW_IF(DIM == 0, "axes must have at least one dimension.");
  KOKKOSFFT_THROW_IF(DIM > rank,
                     "axes size must be less than or equal to the view rank.");

  const std::size_t fft_offset = rank - DIM;
  auto slice_tail = [fft_offset, DIM](const std::vector<std::size_t>& extents) {
    std::vector<std::size_t> slice(DIM);
    for (std::size_t i = 0; i < DIM; ++i) {
      slice.at(i) = extents.at(fft_offset + i);
    }
    return slice;
  };

  std::vector<std::size_t> batch_extents(fft_offset);
  for (std::size_t i = 0; i < fft_offset; ++i) {
    batch_extents.at(i) = fft_extents_full.at(i);
  }
  auto howmany = total_size(batch_extents);

  using extents_type = std::vector<std::size_t>;
  using return_type =
      std::tuple<extents_type, extents_type, extents_type, decltype(howmany)>;

  return return_type(slice_tail(in_extents_full), slice_tail(out_extents_full),
                     slice_tail(fft_extents_full), howmany);
}

/// \brief Compute input, output and fft extents required for FFT
/// libraries based on the input view, output view, axes and shape.
/// Extents are converted into Layout Right
///
/// \tparam InViewType The input view type
/// \tparam OutViewType The output view type
/// \tparam DIM         The dimensionality of the axes
///
/// \param[in] in Input view
/// \param[in] out Output view
/// \param[in] axes Axes over which the FFT operations are performed.
/// \param[in] shape The new shape of the input view. If the shape is zero,
/// no modifications are made.
/// \param[in] is_inplace Whether the FFT is inplace or not
template <typename InViewType, typename OutViewType, std::size_t DIM = 1>
auto get_extents(const InViewType& in, const OutViewType& out,
                 axis_type<DIM> axes, shape_type<DIM> shape = {},
                 bool is_inplace = false) {
  KOKKOSFFT_THROW_IF(!KokkosFFT::Impl::are_valid_axes(in, axes),
                     "input axes are not valid for the view");

  // index map after transpose over axis
  [[maybe_unused]] auto [map, map_inv] =
      KokkosFFT::Impl::get_map_axes(in, axes);

  // Get new shape based on shape parameter
  auto modified_in_shape =
      KokkosFFT::Impl::get_modified_shape(in, out, shape, axes);

  auto map_vec               = to_vector(map);
  auto axes_vec              = to_vector(axes);
  auto modified_in_shape_vec = to_vector(modified_in_shape);

  return get_extents(in, out, map_vec, axes_vec, modified_in_shape_vec,
                     is_inplace);
}

/// \brief Compute input, output and fft extents required for FFT
/// libraries based on the input view, output view, axes and shape.
/// Extents are converted into Layout Right
///
/// \tparam InViewType The input view type
/// \tparam OutViewType The output view type
///
/// \param[in] in Input view
/// \param[in] out Output view
/// \param[in] dim The dimensionality of FFT
/// \param[in] is_inplace  Whether the FFT is inplace or not
template <typename InViewType, typename OutViewType>
auto get_extents(const InViewType& in, const OutViewType& out, std::size_t dim,
                 bool is_inplace = false) {
  using LayoutType = typename InViewType::array_layout;

  // Contiguous map (no permutation)
  std::vector<int> map(InViewType::rank());
  std::iota(map.begin(), map.end(), 0);

  std::vector<int> axes(dim);
  if constexpr (std::is_same_v<LayoutType, typename Kokkos::LayoutLeft>) {
    std::iota(axes.begin(), axes.end(), 0);
    std::reverse(axes.begin(), axes.end());
  } else {
    std::iota(axes.begin(), axes.end(), -dim);
  }

  auto in_shape     = extract_extents(in);
  auto in_shape_vec = to_vector(in_shape);

  return get_extents(in, out, map, axes, in_shape_vec, is_inplace);
}
}  // namespace Impl
}  // namespace KokkosFFT

#endif
