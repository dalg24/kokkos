// SPDX-FileCopyrightText: (C) The Kokkos-FFT development team, see COPYRIGHT.md file
//
// SPDX-License-Identifier: MIT OR Apache-2.0 WITH LLVM-exception

/// \file KokkosFFT_Plans.hpp
/// \brief Wrapping fft plans of different fft libraries
///
/// This file provides KokkosFFT::Plan.
/// This implements a local (no MPI) interface for fft plans

#ifndef KOKKOSFFT_PLANS_HPP
#define KOKKOSFFT_PLANS_HPP

#include <memory>
#include <optional>
#include <vector>
#include <Kokkos_Core.hpp>

#include "KokkosFFT_Asserts.hpp"
#include "KokkosFFT_CheckConditions.hpp"
#include "KokkosFFT_Common_Types.hpp"
#include "KokkosFFT_Container_Helpers.hpp"
#include "KokkosFFT_Convert_Types.hpp"
#include "KokkosFFT_default_types.hpp"
#include "KokkosFFT_Extents.hpp"
#include "KokkosFFT_Layout.hpp"
#include "KokkosFFT_Normalization.hpp"
#include "KokkosFFT_Padding.hpp"
#include "KokkosFFT_Traits.hpp"
#include "KokkosFFT_Transpose.hpp"

#if defined(KOKKOSFFT_ENABLE_TPL_CUFFT)
#include "KokkosFFT_Cuda_plans.hpp"
#include "KokkosFFT_Cuda_transform.hpp"
#endif

#if defined(KOKKOSFFT_ENABLE_TPL_ROCFFT)
#include "KokkosFFT_ROCM_plans.hpp"
#include "KokkosFFT_ROCM_transform.hpp"
#endif

#if defined(KOKKOSFFT_ENABLE_TPL_HIPFFT)
#include "KokkosFFT_HIP_plans.hpp"
#include "KokkosFFT_HIP_transform.hpp"
#endif

#if defined(KOKKOSFFT_ENABLE_TPL_ONEMKL)
#include "KokkosFFT_SYCL_plans.hpp"
#include "KokkosFFT_SYCL_transform.hpp"
#endif

#if defined(KOKKOSFFT_ENABLE_TPL_FFTW)
#include "KokkosFFT_Host_plans.hpp"
#include "KokkosFFT_Host_transform.hpp"
#endif

namespace KokkosFFT {
/// \brief A class that manages a FFT plan of backend FFT library.
///
/// This class is used to manage the FFT plan of backend FFT library.
/// Depending on the input and output Views and axes, appropriate FFT plans are
/// created. If there are inconsistency in input and output views, the
/// compilation would fail.
///
/// \tparam ExecutionSpace: The type of Kokkos execution space
/// \tparam InViewType: Input View type for the FFT
/// \tparam OutViewType: Output View type for the FFT
/// \tparam DIM: The dimensionality of the FFT
template <typename ExecutionSpace, typename InViewType, typename OutViewType,
          std::size_t DIM = 1>
class Plan {
 private:
  static_assert(
      Impl::is_allowed_space_v<ExecutionSpace>,
      "Plan: Backend FFT library is not available for the ExecutionSpace");
  KOKKOSFFT_STATIC_ASSERT_VIEWS_ARE_OPERATABLE(
      (Impl::are_operatable_views_v<ExecutionSpace, InViewType, OutViewType>),
      "Plan");
  static_assert(DIM >= 1 && DIM <= KokkosFFT::MAX_FFT_DIM,
                "Plan: the Rank of FFT axes must be between 1 and MAX_FFT_DIM");
  static_assert(InViewType::rank() >= DIM,
                "Plan: View rank must be larger than or equal to the "
                "Rank of FFT axes");

  //! The type of Kokkos execution pace
  using execSpace = ExecutionSpace;

  //! The value type of input view
  using in_value_type = typename InViewType::non_const_value_type;

  //! The value type of output view
  using out_value_type = typename OutViewType::non_const_value_type;

  //! The real value type of input/output views
  using float_type = Impl::base_floating_point_type<in_value_type>;

  //! The layout type of input/output views
  using layout_type = typename InViewType::array_layout;

  //! The type of FFT plan
  using fft_plan_type =
      typename Impl::FFTPlanType<ExecutionSpace, in_value_type,
                                 out_value_type>::type;

  //! The type of extents of FFT
  using fft_extents_type = std::vector<std::size_t>;

  //! The real value type for normalization
  using normalization_float_type = double;

  //! The type of map for transpose
  using map_type = axis_type<InViewType::rank()>;

  //! The type of extents of input/output views
  using extents_type = shape_type<InViewType::rank()>;

 private:
  //! Execution space
  execSpace m_exec_space;

  //! Dynamically allocatable FFT plan.
  std::unique_ptr<fft_plan_type> m_plan;

  //! FFT extents
  fft_extents_type m_fft_extents;

  //! maps for forward and backward transpose
  map_type m_map, m_map_inv;

  //! whether transpose is needed or not
  bool m_is_transpose_needed = false;

  //! whether crop or pad is needed or not
  bool m_is_crop_or_pad_needed = false;

  //! in-place transform or not
  bool m_is_inplace = false;

  //! axes for FFT
  axis_type<DIM> m_axes;

  //! Shape of the transformed axis of the output
  extents_type m_shape;

  //! directions of FFT
  KokkosFFT::Direction m_direction;

  ///@{
  //! extents of input/output views
  extents_type m_in_extents, m_out_extents;
  ///@}

  ///@{
  //! extents of input/output views after mapping
  extents_type m_in_mapped_extents, m_out_mapped_extents;
  ///@}

 public:
  /// \brief Constructor for one-dimensional FFT
  ///
  /// \param exec_space [in] Kokkos execution space for this plan
  /// \param in [in] Input data
  /// \param out [in] Output data
  /// \param direction [in] Direction of FFT (forward/backward)
  /// \param axis [in] Axis over which FFT is performed
  /// \param n [in] Length of the transformed axis of the output (default,
  /// nullopt)
  //
  explicit Plan(const ExecutionSpace& exec_space, const InViewType& in,
                const OutViewType& out, KokkosFFT::Direction direction,
                int axis, std::optional<std::size_t> n = std::nullopt)
      : Plan(exec_space, in, out, direction, axis_type<DIM>({axis}),
             shape_type<DIM>{n.value_or(0)}) {}

  /// \brief Constructor for multidimensional FFT
  ///
  /// \param exec_space [in] Kokkos execution space for this plan
  /// \param in [in] Input data
  /// \param out [in] Output data
  /// \param direction [in] Direction of FFT (forward/backward)
  /// \param axes [in] Axes over which FFT is performed
  /// \param s [in] Shape of the transformed axis of the output (default, {})
  //
  explicit Plan(const ExecutionSpace& exec_space, const InViewType& in,
                const OutViewType& out, KokkosFFT::Direction direction,
                axis_type<DIM> axes, shape_type<DIM> s = {})
      : m_exec_space(exec_space),
        m_axes(axes),
        m_direction(direction),
        m_in_extents(Impl::extract_extents(in)),
        m_out_extents(Impl::extract_extents(out)) {
    KOKKOSFFT_THROW_IF(!Impl::are_valid_axes(in, m_axes),
                       "axes are invalid for in/out views");
    if constexpr (Impl::is_real_v<in_value_type>) {
      KOKKOSFFT_THROW_IF(m_direction != KokkosFFT::Direction::forward,
                         "real to complex transform is constructed "
                         "with backward direction.");
    }

    if constexpr (Impl::is_real_v<out_value_type>) {
      KOKKOSFFT_THROW_IF(m_direction != KokkosFFT::Direction::backward,
                         "complex to real transform is constructed "
                         "with forward direction.");
    }

    std::tie(m_map, m_map_inv) = Impl::get_map_axes(in, axes);
    m_is_transpose_needed      = Impl::is_transpose_needed(m_map);
    m_shape                    = Impl::get_modified_shape(in, out, s, m_axes);
    m_is_crop_or_pad_needed    = m_in_extents != m_shape;
    m_is_inplace               = Impl::are_aliasing(in.data(), out.data());
    KOKKOSFFT_THROW_IF(m_is_inplace && m_is_crop_or_pad_needed,
                       "In-place transform is not supported with reshape. "
                       "Please use out-of-place transform.");

    if (m_is_transpose_needed) {
      auto in_tmp_extents = m_is_crop_or_pad_needed ? m_shape : m_in_extents;
      m_in_mapped_extents = Impl::compute_mapped_extents(in_tmp_extents, m_map);
      m_out_mapped_extents = Impl::compute_mapped_extents(m_out_extents, m_map);
    }

    Impl::setup<ExecutionSpace, float_type>();
    bool is_truly_inplace = m_is_inplace && !m_is_transpose_needed;
    m_fft_extents = Impl::create_plan(exec_space, m_plan, in, out, direction,
                                      axes, s, is_truly_inplace);
  }

  ~Plan() noexcept = default;

  Plan()                       = delete;
  Plan(const Plan&)            = delete;
  Plan& operator=(const Plan&) = delete;
  Plan& operator=(Plan&&)      = delete;
  Plan(Plan&&)                 = delete;

  void execute_impl(const InViewType& in, const OutViewType& out,
                    KokkosFFT::Normalization norm =
                        KokkosFFT::Normalization::backward) const {
    // sanity check that the plan is consistent with the input/output views
    good(in, out);

    using ManageableInViewType =
        typename Impl::manageable_view_type<InViewType>::type;
    using ManageableOutViewType =
        typename Impl::manageable_view_type<OutViewType>::type;

    ManageableInViewType in_s;
    InViewType in_tmp;
    if (m_is_crop_or_pad_needed) {
      using LayoutType = typename ManageableInViewType::array_layout;
      in_s             = ManageableInViewType("in_s",
                                              Impl::create_layout<LayoutType>(m_shape));
      Impl::crop_or_pad(m_exec_space, in, in_s);
      in_tmp = in_s;
    } else {
      in_tmp = in;
    }

    if (m_is_transpose_needed) {
      using LayoutType = typename ManageableInViewType::array_layout;
      ManageableInViewType const in_T(
          "in_T", Impl::create_layout<LayoutType>(m_in_mapped_extents));
      ManageableOutViewType const out_T(
          "out_T", Impl::create_layout<LayoutType>(m_out_mapped_extents));

      InViewType in_padded   = in_tmp;
      OutViewType out_padded = out;
      bool to_bounds_check   = false;
      if (m_is_inplace) {
        // It is ensured that both in_value_type and out_value_type cannot be
        // real at the same time
        constexpr std::size_t rank = InViewType::rank();
        auto non_negative_axes     = Impl::convert_base_int_type<std::size_t>(
            Impl::convert_negative_axes(m_axes, rank));

        if constexpr (Impl::is_real_v<in_value_type>) {
          auto in_padded_extents = Impl::compute_padded_extents<in_value_type>(
              m_out_extents, non_negative_axes);
          in_padded =
              InViewType(in_tmp.data(),
                         Impl::create_layout<LayoutType>(in_padded_extents));
          to_bounds_check = true;
        } else if constexpr (Impl::is_real_v<out_value_type>) {
          auto out_padded_extents =
              Impl::compute_padded_extents<out_value_type>(m_in_extents,
                                                           non_negative_axes);
          out_padded = OutViewType(
              out.data(), Impl::create_layout<LayoutType>(out_padded_extents));
        }
      }
      Impl::transpose(m_exec_space, in_padded, in_T, m_map, to_bounds_check);
      execute_fft(in_T, out_T, norm);
      Impl::transpose(m_exec_space, out_T, out_padded, m_map_inv);
    } else {
      execute_fft(in_tmp, out, norm);
    }
  }

 private:
  void execute_fft(const InViewType& in, const OutViewType& out,
                   KokkosFFT::Normalization norm) const {
    auto* idata = reinterpret_cast<
        typename Impl::fft_data_type<execSpace, in_value_type>::type*>(
        in.data());
    auto* odata = reinterpret_cast<
        typename Impl::fft_data_type<execSpace, out_value_type>::type*>(
        out.data());

    auto const direction = Impl::direction_type<execSpace>(m_direction);
    Impl::exec_plan(*m_plan, idata, odata, direction);

    if constexpr (Impl::is_complex_v<in_value_type> &&
                  Impl::is_real_v<out_value_type>) {
      if (m_is_inplace && !m_is_transpose_needed) {
        // For the in-place Complex to Real transform, the output must be
        // reshaped to fit the original size (in.size() * 2) for correct
        // normalization
        Kokkos::View<out_value_type*, execSpace> out_tmp(out.data(),
                                                         in.size() * 2);
        Impl::normalize<normalization_float_type>(
            m_exec_space, out_tmp, m_direction, norm, m_fft_extents);
        return;
      }
    }
    Impl::normalize<normalization_float_type>(m_exec_space, out, m_direction,
                                              norm, m_fft_extents);
  }

  /// \brief Sanity check of the plan used to call FFT interface with
  ///        pre-defined FFT plan. This raises an error if there is an
  ///        inconsistency between FFT function and plan
  ///
  /// \param in [in] Input data
  /// \param out [in] Output data
  void good(const InViewType& in, const OutViewType& out) const {
    auto in_extents  = Impl::extract_extents(in);
    auto out_extents = Impl::extract_extents(out);

    KOKKOSFFT_THROW_IF(in_extents != m_in_extents,
                       "extents of input View for plan and "
                       "execution are not identical.");

    KOKKOSFFT_THROW_IF(out_extents != m_out_extents,
                       "extents of output View for plan and "
                       "execution are not identical.");

    bool is_inplace = Impl::are_aliasing(in.data(), out.data());
    KOKKOSFFT_THROW_IF(is_inplace != m_is_inplace,
                       "If the plan is in-place, the input and output Views "
                       "must be identical.");
  }
};
}  // namespace KokkosFFT

#endif
