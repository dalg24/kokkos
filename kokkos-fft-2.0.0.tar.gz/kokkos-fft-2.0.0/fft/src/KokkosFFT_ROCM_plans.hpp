// SPDX-FileCopyrightText: (C) The Kokkos-FFT development team, see COPYRIGHT.md file
//
// SPDX-License-Identifier: MIT OR Apache-2.0 WITH LLVM-exception

#ifndef KOKKOSFFT_ROCM_PLANS_HPP
#define KOKKOSFFT_ROCM_PLANS_HPP

#include <memory>
#include <Kokkos_Core.hpp>
#include <Kokkos_Profiling_ScopedRegion.hpp>

#include "KokkosFFT_Asserts.hpp"
#include "KokkosFFT_Container_Helpers.hpp"
#include "KokkosFFT_Convert_Types.hpp"
#include "KokkosFFT_Extents.hpp"
#include "KokkosFFT_ROCM_types.hpp"
#include "KokkosFFT_Traits.hpp"

namespace KokkosFFT {
namespace Impl {

template <typename ExecutionSpace, typename T,
          std::enable_if_t<std::is_same_v<ExecutionSpace, Kokkos::HIP>,
                           std::nullptr_t> = nullptr>
void setup() {
  [[maybe_unused]] static bool once = [] {
    if (!(Kokkos::is_initialized() || Kokkos::is_finalized())) {
      Kokkos::abort(
          "Error: KokkosFFT APIs must not be called before initializing "
          "Kokkos.\n");
    }
    if (Kokkos::is_finalized()) {
      Kokkos::abort(
          "Error: KokkosFFT APIs must not be called after finalizing "
          "Kokkos.\n");
    }

    rocfft_status status = rocfft_setup();
    if (status != rocfft_status_success) Kokkos::abort("rocfft_setup failed");

    // Register cleanup function as a hook in Kokkos::finalize
    Kokkos::push_finalize_hook([]() {
      rocfft_status status = rocfft_cleanup();
      if (status != rocfft_status_success)
        Kokkos::abort("rocfft_cleanup failed");
    });
    return true;
  }();
}

// batched transform, over ND Views
template <typename ExecutionSpace, typename PlanType, typename InViewType,
          typename OutViewType, std::size_t fft_rank = 1,
          std::enable_if_t<std::is_same_v<ExecutionSpace, Kokkos::HIP>,
                           std::nullptr_t> = nullptr>
auto create_plan(const ExecutionSpace& exec_space,
                 std::unique_ptr<PlanType>& plan, const InViewType& in,
                 const OutViewType& out, Direction direction,
                 axis_type<fft_rank> axes, shape_type<fft_rank> s,
                 bool is_inplace) {
  KOKKOSFFT_STATIC_ASSERT_VIEWS_ARE_OPERATABLE(
      (KokkosFFT::Impl::are_operatable_views_v<ExecutionSpace, InViewType,
                                               OutViewType>),
      "create_plan");
  static_assert(InViewType::rank() >= fft_rank,
                "create_plan: Rank of View must be larger than "
                "Rank of FFT.");

  using in_value_type  = typename InViewType::non_const_value_type;
  using out_value_type = typename OutViewType::non_const_value_type;

  Kokkos::Profiling::ScopedRegion region("KokkosFFT::create_plan[TPL_rocfft]");
  constexpr auto type =
      KokkosFFT::Impl::transform_type<ExecutionSpace, in_value_type,
                                      out_value_type>::type();
  auto [in_extents, out_extents, fft_extents, howmany] =
      KokkosFFT::Impl::get_extents(in, out, axes, s, is_inplace);

  // Create a plan
  plan = std::make_unique<PlanType>(type, in_extents, out_extents, fft_extents,
                                    howmany, direction, is_inplace);
  plan->commit(exec_space);
  plan->set_work_area();

  return fft_extents;
}

// batched transform, over ND Views
template <typename ExecutionSpace, typename PlanType, typename InViewType,
          typename OutViewType,
          std::enable_if_t<std::is_same_v<ExecutionSpace, Kokkos::HIP>,
                           std::nullptr_t> = nullptr>
auto create_dynplan(const ExecutionSpace& exec_space,
                    std::unique_ptr<PlanType>& plan, const InViewType& in,
                    const OutViewType& out, Direction direction,
                    std::size_t dim, bool is_inplace) {
  KOKKOSFFT_STATIC_ASSERT_VIEWS_ARE_OPERATABLE(
      (KokkosFFT::Impl::are_operatable_views_v<ExecutionSpace, InViewType,
                                               OutViewType>),
      "create_dynplan");
  using in_value_type  = typename InViewType::non_const_value_type;
  using out_value_type = typename OutViewType::non_const_value_type;

  Kokkos::Profiling::ScopedRegion region(
      "KokkosFFT::create_dynplan[TPL_rocfft]");
  constexpr auto type =
      KokkosFFT::Impl::transform_type<ExecutionSpace, in_value_type,
                                      out_value_type>::type();
  auto [in_extents, out_extents, fft_extents, howmany] =
      KokkosFFT::Impl::get_extents(in, out, dim, is_inplace);

  // Create a plan
  plan = std::make_unique<PlanType>(type, in_extents, out_extents, fft_extents,
                                    howmany, direction, is_inplace);
  plan->commit(exec_space);

  return fft_extents;
}

}  // namespace Impl
}  // namespace KokkosFFT

#endif
