// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project
#ifndef KOKKOSBATCHED_TRSV_SERIAL_INTERNAL_HPP
#define KOKKOSBATCHED_TRSV_SERIAL_INTERNAL_HPP

/// \author Kyungjoo Kim (kyukim@sandia.gov)
/// \author Yuuichi Asahi (yuuichi.asahi@cea.fr)

#include "KokkosBatched_Util.hpp"

#include "KokkosBlas1_set_impl.hpp"
#include "KokkosBlas1_serial_scal_impl.hpp"
#include "KokkosBatched_InnerTrsm_Serial_Impl.hpp"
#include "KokkosBlas2_serial_gemv_internal.hpp"

namespace KokkosBatched {
namespace Impl {

///
/// Serial Internal Impl
/// ====================

///
/// Lower
///

template <typename AlgoType>
struct SerialTrsvInternalLower {
  template <typename Op, typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const bool use_unit_diag, Op op, const int m, const ScalarType alpha,
                                           const ValueType *KOKKOS_RESTRICT A, const int as0, const int as1,
                                           /**/ ValueType *KOKKOS_RESTRICT b, const int bs0);
};

template <>
template <typename Op, typename ScalarType, typename ValueType>
KOKKOS_INLINE_FUNCTION int SerialTrsvInternalLower<Algo::Trsv::Unblocked>::invoke(const bool use_unit_diag, Op op,
                                                                                  const int m, const ScalarType alpha,
                                                                                  const ValueType *KOKKOS_RESTRICT A,
                                                                                  const int as0, const int as1,
                                                                                  /**/ ValueType *KOKKOS_RESTRICT b,
                                                                                  const int bs0) {
  const ScalarType one(1.0), zero(0.0);

  if (alpha == zero)
    KokkosBlas::Impl::SerialSetInternal::invoke(m, zero, b, bs0);
  else {
    if (alpha != one) KokkosBlas::Impl::SerialScaleInternal::invoke(m, alpha, b, bs0);
    if (m <= 0) return 0;

    for (int p = 0; p < m; ++p) {
      const int iend = m - p - 1;

      const ValueType *KOKKOS_RESTRICT a21 = iend ? A + (p + 1) * as0 + p * as1 : nullptr;

      ValueType *KOKKOS_RESTRICT beta1 = b + p * bs0, *KOKKOS_RESTRICT b2 = iend ? beta1 + bs0 : nullptr;

      // with KOKKOS_RESTRICT a compiler assumes that the pointer is not
      // accessed by others op(/=) uses this pointer and changes the associated
      // values, which brings a compiler problem
      if (!use_unit_diag) *beta1 = *beta1 / op(A[p * as0 + p * as1]);

      for (int i = 0; i < iend; ++i) b2[i * bs0] -= op(a21[i * as0]) * (*beta1);
    }
  }
  return 0;
}

template <>
template <typename Op, typename ScalarType, typename ValueType>
KOKKOS_INLINE_FUNCTION int SerialTrsvInternalLower<Algo::Trsv::Blocked>::invoke(const bool use_unit_diag, Op op,
                                                                                const int m, const ScalarType alpha,
                                                                                const ValueType *KOKKOS_RESTRICT A,
                                                                                const int as0, const int as1,
                                                                                /**/ ValueType *KOKKOS_RESTRICT b,
                                                                                const int bs0) {
  const ScalarType one(1.0), zero(0.0), minus_one(-1.0);

  if (alpha == zero)
    KokkosBlas::Impl::SerialSetInternal::invoke(m, zero, b, bs0);
  else {
    if (alpha != one) KokkosBlas::Impl::SerialScaleInternal::invoke(m, alpha, b, bs0);
    if (m <= 0) return 0;

    auto host_or_device = [&](auto tag) {
      constexpr int mb = Algo::Trsv::Blocked::Impl::mb<decltype(tag)>();
      InnerTrsmLeftLowerUnitDiag<mb> trsm_u(as0, as1, bs0, 0);
      InnerTrsmLeftLowerNonUnitDiag<mb> trsm_n(as0, as1, bs0, 0);

      for (int p = 0; p < m; p += mb) {
        const int pb = ((p + mb) > m ? (m - p) : mb);

        // trsm update
        const ValueType *KOKKOS_RESTRICT Ap = A + p * as0 + p * as1;
        /**/ ValueType *KOKKOS_RESTRICT bp  = b + p * bs0;

        if (use_unit_diag)
          trsm_u.serial_invoke(op, Ap, pb, 1, bp);
        else
          trsm_n.serial_invoke(op, Ap, pb, 1, bp);

        // gemv update
        KokkosBlas::Impl::SerialGemvInternal<Algo::Gemv::Blocked>::invoke(op, m - p - pb, pb, minus_one, Ap + pb * as0,
                                                                          as0, as1, bp, bs0, one, bp + pb * bs0, bs0);
      }
    };
    KOKKOS_IF_ON_HOST((host_or_device(Algo::Trsv::Blocked::Impl::Host{});))
    KOKKOS_IF_ON_DEVICE((host_or_device(Algo::Trsv::Blocked::Impl::Device{});))
  }
  return 0;
}

///
/// Upper
///

template <typename AlgoType>
struct SerialTrsvInternalUpper {
  template <typename Op, typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const bool use_unit_diag, Op op, const int m, const ScalarType alpha,
                                           const ValueType *KOKKOS_RESTRICT A, const int as0, const int as1,
                                           /**/ ValueType *KOKKOS_RESTRICT b, const int bs0);
};

template <>
template <typename Op, typename ScalarType, typename ValueType>
KOKKOS_INLINE_FUNCTION int SerialTrsvInternalUpper<Algo::Trsv::Unblocked>::invoke(const bool use_unit_diag, Op op,
                                                                                  const int m, const ScalarType alpha,
                                                                                  const ValueType *KOKKOS_RESTRICT A,
                                                                                  const int as0, const int as1,
                                                                                  /**/ ValueType *KOKKOS_RESTRICT b,
                                                                                  const int bs0) {
  const ScalarType one(1.0), zero(0.0);

  if (alpha == zero)
    KokkosBlas::Impl::SerialSetInternal::invoke(m, zero, b, bs0);
  else {
    if (alpha != one) KokkosBlas::Impl::SerialScaleInternal::invoke(m, alpha, b, bs0);
    if (m <= 0) return 0;

    ValueType *KOKKOS_RESTRICT b0 = b;
    for (int p = (m - 1); p >= 0; --p) {
      const int iend = p;

      const ValueType *KOKKOS_RESTRICT a01  = A + p * as1;
      /**/ ValueType *KOKKOS_RESTRICT beta1 = b + p * bs0;

      // with KOKKOS_RESTRICT a compiler assumes that the pointer is not
      // accessed by others op(/=) uses this pointer and changes the associated
      // values, which brings a compiler problem
      if (!use_unit_diag) *beta1 = *beta1 / op(A[p * as0 + p * as1]);

      for (int i = 0; i < iend; ++i) b0[i * bs0] -= op(a01[i * as0]) * (*beta1);
    }
  }
  return 0;
}

template <>
template <typename Op, typename ScalarType, typename ValueType>
KOKKOS_INLINE_FUNCTION int SerialTrsvInternalUpper<Algo::Trsv::Blocked>::invoke(const bool use_unit_diag, Op op,
                                                                                const int m, const ScalarType alpha,
                                                                                const ValueType *KOKKOS_RESTRICT A,
                                                                                const int as0, const int as1,
                                                                                /**/ ValueType *KOKKOS_RESTRICT b,
                                                                                const int bs0) {
  const ScalarType one(1.0), zero(0.0), minus_one(-1.0);

  // note that parallel range is different ( m*n vs m-1*n);
  if (alpha == zero)
    KokkosBlas::Impl::SerialSetInternal::invoke(m, zero, b, bs0);
  else {
    if (alpha != one) KokkosBlas::Impl::SerialScaleInternal::invoke(m, alpha, b, bs0);
    if (m <= 0) return 0;

    auto host_or_device = [&](auto tag) {
      constexpr int mb = Algo::Trsm::Blocked::Impl::mb<decltype(tag)>();
      InnerTrsmLeftUpperUnitDiag<mb> trsm_u(as0, as1, bs0, 0);
      InnerTrsmLeftUpperNonUnitDiag<mb> trsm_n(as0, as1, bs0, 0);

      for (int pp = 0; pp < m; pp += mb) {
        const int ptmp = (m - pp - mb), p = (ptmp < 0 ? 0 : ptmp), pb = (mb + (ptmp < 0) * ptmp);

        // trsm update
        const ValueType *KOKKOS_RESTRICT Ap = A + p * as0 + p * as1;
        /**/ ValueType *KOKKOS_RESTRICT bp  = b + p * bs0;

        if (use_unit_diag)
          trsm_u.serial_invoke(op, Ap, pb, 1, bp);
        else
          trsm_n.serial_invoke(op, Ap, pb, 1, bp);

        // gemv update
        KokkosBlas::Impl::SerialGemvInternal<Algo::Gemv::Blocked>::invoke(op, p, pb, minus_one, Ap - p * as0, as0, as1,
                                                                          bp, bs0, one, b, bs0);
      }
    };
    KOKKOS_IF_ON_HOST((host_or_device(Algo::Trsm::Blocked::Impl::Host{});))
    KOKKOS_IF_ON_DEVICE((host_or_device(Algo::Trsm::Blocked::Impl::Device{});))
  }
  return 0;
}

}  // namespace Impl

template <typename AlgoType>
struct [[deprecated("Use KokkosBatched::SerialTrsv instead")]] SerialTrsvInternalLower {
  template <typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const bool use_unit_diag, const int m, const ScalarType alpha,
                                           const ValueType *KOKKOS_RESTRICT A, const int as0, const int as1,
                                           /**/ ValueType *KOKKOS_RESTRICT b, const int bs0) {
    return Impl::SerialTrsvInternalLower<AlgoType>::invoke(use_unit_diag, KokkosBlas::Impl::OpID(), m, alpha, A, as0,
                                                           as1, b, bs0);
  }
};

template <typename AlgoType>
struct [[deprecated("Use KokkosBatched::SerialTrsv instead")]] SerialTrsvInternalUpper {
  template <typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const bool use_unit_diag, const int m, const ScalarType alpha,
                                           const ValueType *KOKKOS_RESTRICT A, const int as0, const int as1,
                                           /**/ ValueType *KOKKOS_RESTRICT b, const int bs0) {
    return Impl::SerialTrsvInternalUpper<AlgoType>::invoke(use_unit_diag, KokkosBlas::Impl::OpID(), m, alpha, A, as0,
                                                           as1, b, bs0);
  }
};

}  // namespace KokkosBatched

#endif
