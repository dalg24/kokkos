// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project
#ifndef KOKKOSBATCHED_AXPY_IMPL_HPP
#define KOKKOSBATCHED_AXPY_IMPL_HPP

/// \author Kim Liegeois (knliege@sandia.gov)

#include "KokkosBatched_Util.hpp"
#include "KokkosBlas1_team_axpby.hpp"

namespace KokkosBatched {
namespace Impl {

template <typename XViewType, typename YViewType, typename alphaViewType>
KOKKOS_INLINE_FUNCTION static int checkAxpyInput([[maybe_unused]] const alphaViewType& alpha,
                                                 [[maybe_unused]] const XViewType& X,
                                                 [[maybe_unused]] const YViewType& Y) {
  static_assert(Kokkos::is_view_v<XViewType>, "KokkosBatched::axpy: XViewType is not a Kokkos::View.");
  static_assert(Kokkos::is_view_v<YViewType>, "KokkosBatched::axpy: YViewType is not a Kokkos::View.");

  if constexpr (Kokkos::is_view_v<alphaViewType>) {
    static_assert(XViewType::rank == 2, "KokkosBatched::axpy: XViewType must have rank 2.");
    static_assert(YViewType::rank == 2, "KokkosBatched::axpy: YViewType must have rank 2.");
    static_assert(alphaViewType::rank == 1, "KokkosBatched::axpy: alphaViewType must have rank 1.");
#ifndef NDEBUG
    // Check compatibility of dimensions at run time.
    if (X.extent_int(0) != Y.extent_int(0) || X.extent_int(1) != Y.extent_int(1)) {
      Kokkos::printf(
          "KokkosBatched::axpy: Dimensions of X and Y do not match: X: %d x %d, "
          "Y: %d x %d\n",
          X.extent_int(0), X.extent_int(1), Y.extent_int(0), Y.extent_int(1));
      return 1;
    }
    if (X.extent(0) != alpha.extent(0)) {
      Kokkos::printf(
          "KokkosBatched::axpy: First dimension of X and alpha do not match: X: "
          "%d x %d, alpha: %d\n",
          X.extent_int(0), X.extent_int(1), alpha.extent_int(0));
      return 1;
    }
#endif
  } else {
    static_assert(XViewType::rank == 1, "KokkosBatched::axpy: XViewType must have rank 1 if alpha is a scalar.");
    static_assert(YViewType::rank == 1, "KokkosBatched::axpy: YViewType must have rank 1 if alpha is a scalar.");
#ifndef NDEBUG
    // Check compatibility of dimensions at run time.
    if (X.extent_int(0) != Y.extent_int(0)) {
      Kokkos::printf(
          "KokkosBatched::axpy: Dimensions of X and Y do not match: X: %d, "
          "Y: %d\n",
          X.extent_int(0), Y.extent_int(0));
      return 1;
    }
#endif
  }
  return 0;
}

///
/// Serial Internal Impl
/// ====================
struct SerialAxpyInternal {
  template <typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const int m, const ScalarType alpha, const ValueType* KOKKOS_RESTRICT X,
                                           const int xs0,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0) {
#if defined(KOKKOS_ENABLE_PRAGMA_UNROLL)
#pragma unroll
#endif
    for (int i = 0; i < m; ++i) Y[i * ys0] += alpha * X[i * xs0];

    return 0;
  }

  template <typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const int m, const ScalarType* KOKKOS_RESTRICT alpha, const int alphas0,
                                           const ValueType* KOKKOS_RESTRICT X, const int xs0,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0) {
#if defined(KOKKOS_ENABLE_PRAGMA_UNROLL)
#pragma unroll
#endif
    for (int i = 0; i < m; ++i) Y[i * ys0] += alpha[i * alphas0] * X[i * xs0];

    return 0;
  }

  template <typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const int m, const int n, const ScalarType* KOKKOS_RESTRICT alpha,
                                           const int alphas0, const ValueType* KOKKOS_RESTRICT X, const int xs0,
                                           const int xs1,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0, const int ys1) {
    if (xs0 > xs1)
      for (int i = 0; i < m; ++i) invoke(n, alpha[i * alphas0], X + i * xs0, xs1, Y + i * ys0, ys1);
    else
      for (int j = 0; j < n; ++j) invoke(m, alpha, alphas0, X + j * xs1, xs0, Y + j * ys1, ys0);

    return 0;
  }
};

///
/// Team Internal Impl
/// ====================
struct TeamAxpyInternal {
  template <typename MemberType, typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType& member, const int m, const ScalarType alpha,
                                           const ValueType* KOKKOS_RESTRICT X, const int xs0,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0) {
    Kokkos::parallel_for(Kokkos::TeamThreadRange(member, m), [&](const int& i) { Y[i * ys0] += alpha * X[i * xs0]; });
    // member.team_barrier();
    return 0;
  }

  template <typename MemberType, typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType& member, const int m,
                                           const ScalarType* KOKKOS_RESTRICT alpha, const int alphas0,
                                           const ValueType* KOKKOS_RESTRICT X, const int xs0,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0) {
    Kokkos::parallel_for(Kokkos::TeamThreadRange(member, m),
                         [&](const int& i) { Y[i * ys0] += alpha[i * alphas0] * X[i * xs0]; });
    // member.team_barrier();
    return 0;
  }

  template <typename MemberType, typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType& member, const int m, const int n,
                                           const ScalarType* KOKKOS_RESTRICT alpha, const int alphas0,
                                           const ValueType* KOKKOS_RESTRICT X, const int xs0, const int xs1,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0, const int ys1) {
    if (m > n) {
      Kokkos::parallel_for(Kokkos::TeamThreadRange(member, m), [&](const int& i) {
        SerialAxpyInternal::invoke(n, alpha[i * alphas0], X + i * xs0, xs1, Y + i * ys0, ys1);
      });
    } else {
      Kokkos::parallel_for(Kokkos::TeamThreadRange(member, n), [&](const int& j) {
        SerialAxpyInternal::invoke(m, alpha, alphas0, X + j * xs1, xs0, Y + j * ys1, ys0);
      });
    }
    // member.team_barrier();
    return 0;
  }
};

///
/// TeamVector Internal Impl
/// ========================
struct TeamVectorAxpyInternal {
  template <typename MemberType, typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType& member, const int m, const ScalarType alpha,
                                           const ValueType* KOKKOS_RESTRICT X, const int xs0,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0) {
    Kokkos::parallel_for(Kokkos::TeamVectorRange(member, m), [&](const int& i) { Y[i * ys0] += alpha * X[i * xs0]; });
    // member.team_barrier();
    return 0;
  }

  template <typename MemberType, typename ScalarType, typename ValueType>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType& member, const int m,
                                           const ScalarType* KOKKOS_RESTRICT alpha, const int alphas0,
                                           const ValueType* KOKKOS_RESTRICT X, const int xs0,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0) {
    Kokkos::parallel_for(Kokkos::TeamVectorRange(member, m),
                         [&](const int& i) { Y[i * ys0] += alpha[i * alphas0] * X[i * xs0]; });
    // member.team_barrier();
    return 0;
  }

  template <typename MemberType, typename ScalarType, typename ValueType, typename layout>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType& member, const int m, const int n,
                                           const ScalarType* KOKKOS_RESTRICT alpha, const int alphas0,
                                           const ValueType* KOKKOS_RESTRICT X, const int xs0, const int xs1,
                                           /* */ ValueType* KOKKOS_RESTRICT Y, const int ys0, const int ys1) {
    Kokkos::parallel_for(Kokkos::TeamVectorRange(member, 0, m * n), [&](const int& iTemp) {
      int i, j;
      getIndices<int, layout>(iTemp, n, m, j, i);
      Y[i * ys0 + j * ys1] += alpha[i * alphas0] * X[i * xs0 + j * xs1];
    });
    // member.team_barrier();
    return 0;
  }
};

}  // namespace Impl

///
/// Serial Impl
/// ===========

template <typename XViewType, typename YViewType, typename alphaViewType>
KOKKOS_INLINE_FUNCTION int SerialAxpy::invoke(const alphaViewType& alpha, const XViewType& X, const YViewType& Y) {
  auto info = Impl::checkAxpyInput(alpha, X, Y);
  if (info) return info;

  if constexpr (Kokkos::is_view_v<alphaViewType>) {
    return Impl::SerialAxpyInternal::template invoke<typename alphaViewType::non_const_value_type,
                                                     typename XViewType::non_const_value_type>(
        X.extent(0), X.extent(1), alpha.data(), alpha.stride(0), X.data(), X.stride(0), X.stride(1), Y.data(),
        Y.stride(0), Y.stride(1));
  } else {
    return Impl::SerialAxpyInternal::template invoke<alphaViewType, typename XViewType::non_const_value_type>(
        X.extent(0), alpha, X.data(), X.stride(0), Y.data(), Y.stride(0));
  }
}

///
/// Team Impl
/// =========

template <typename MemberType>
template <typename XViewType, typename YViewType, typename alphaViewType>
KOKKOS_INLINE_FUNCTION int TeamAxpy<MemberType>::invoke(const MemberType& member, const alphaViewType& alpha,
                                                        const XViewType& X, const YViewType& Y) {
  auto info = Impl::checkAxpyInput(alpha, X, Y);
  if (info) return info;

  if constexpr (Kokkos::is_view_v<alphaViewType>) {
    if (X.extent(0) == 1) {
      KokkosBlas::Experimental::axpy<MemberType>(member, alpha.data()[0], Kokkos::subview(X, 0, Kokkos::ALL),
                                                 Kokkos::subview(Y, 0, Kokkos::ALL));
      return 0;
    }

    return Impl::TeamAxpyInternal::template invoke<MemberType, typename alphaViewType::non_const_value_type,
                                                   typename XViewType::non_const_value_type>(
        member, X.extent(0), X.extent(1), alpha.data(), alpha.stride(0), X.data(), X.stride(0), X.stride(1), Y.data(),
        Y.stride(0), Y.stride(1));
  } else {
    KokkosBlas::Experimental::axpy<MemberType>(member, alpha, X, Y);
    return 0;
  }
}

///
/// TeamVector Impl
/// ===============

template <typename MemberType>
template <typename XViewType, typename YViewType, typename alphaViewType>
KOKKOS_INLINE_FUNCTION int TeamVectorAxpy<MemberType>::invoke(const MemberType& member, const alphaViewType& alpha,
                                                              const XViewType& X, const YViewType& Y) {
  auto info = Impl::checkAxpyInput(alpha, X, Y);
  if (info) return info;

  if constexpr (Kokkos::is_view_v<alphaViewType>) {
    if (X.extent(0) == 1) {
      KokkosBlas::Experimental::axpy<MemberType>(member, alpha.data()[0], Kokkos::subview(X, 0, Kokkos::ALL),
                                                 Kokkos::subview(Y, 0, Kokkos::ALL));
      return 0;
    }

    return Impl::TeamVectorAxpyInternal::invoke<MemberType, typename alphaViewType::non_const_value_type,
                                                typename XViewType::non_const_value_type,
                                                typename XViewType::array_layout>(
        member, X.extent(0), X.extent(1), alpha.data(), alpha.stride(0), X.data(), X.stride(0), X.stride(1), Y.data(),
        Y.stride(0), Y.stride(1));
  } else {
    KokkosBlas::Experimental::axpy<MemberType>(member, alpha, X, Y);
    return 0;
  }
}

}  // namespace KokkosBatched

#endif
