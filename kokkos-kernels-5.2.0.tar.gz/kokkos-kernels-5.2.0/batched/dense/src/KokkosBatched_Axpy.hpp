// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
// SPDX-FileCopyrightText: Copyright Contributors to the Kokkos project
#ifndef KOKKOSBATCHED_AXPY_HPP
#define KOKKOSBATCHED_AXPY_HPP

/// \author Kim Liegeois (knliege@sandia.gov)
/// \author Yuuichi Asahi (yuuichi.asahi@cea.fr)

#include "KokkosBatched_Util.hpp"
#include "KokkosBatched_Vector.hpp"

namespace KokkosBatched {

/// \brief Serial Batched AXPY:
///   y_l <- alpha_l * x_l + y_l for all l = 1, ..., N
/// where:
///   * N is the number of vectors,
///   * x_1, ..., x_N are the N input vectors,
///   * y_1, ..., y_N are the N output vectors,
///   * alpha_1, ..., alpha_N are N scaling factors for x_1, ..., x_N.
///
/// \tparam XViewType: Input type for X, needs to be a 1D or 2D view
/// \tparam YViewType: Input type for Y, needs to be a 1D or 2D view
/// \tparam alphaViewType: Input type for alpha, needs to be a 1D view or Scalar
///
/// \param[in] alpha: input coefficient for X, a rank 1 view or a scalar
/// \param[in] X: Input vector X, a rank 1 or 2 view
/// \param[in/out] Y: Output vector Y, a rank 1 or 2 view
///
/// No nested parallel_for is used inside of the function.
///

struct SerialAxpy {
  template <typename XViewType, typename YViewType, typename alphaViewType>
  KOKKOS_INLINE_FUNCTION static int invoke(const alphaViewType &alpha, const XViewType &X, const YViewType &Y);
};

/// \brief Team Batched AXPY:
///   y_l <- alpha_l * x_l + y_l for all l = 1, ..., N
/// where:
///   * N is the number of vectors,
///   * x_1, ..., x_N are the N input vectors,
///   * y_1, ..., y_N are the N output vectors,
///   * alpha_1, ..., alpha_N are N scaling factors for x_1, ..., x_N.
///
/// \tparam MemberType: TeamPolicy member type
/// \tparam XViewType: Input type for X, needs to be a 1D or 2D view
/// \tparam YViewType: Input type for Y, needs to be a 1D or 2D view
/// \tparam alphaViewType: Input type for alpha, needs to be a 1D view or Scalar
///
/// \param[in] member: TeamPolicy member
/// \param[in] alpha: input coefficient for X, a rank 1 view or a scalar
/// \param[in] X: Input vector X, a rank 1 or 2 view
/// \param[in/out] Y: Output vector Y, a rank 1 or 2 view
///
/// A nested parallel_for with TeamThreadRange is used.
///

template <typename MemberType>
struct TeamAxpy {
  template <typename XViewType, typename YViewType, typename alphaViewType>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType &member, const alphaViewType &alpha, const XViewType &X,
                                           const YViewType &Y);
};

/// \brief TeamVector Batched AXPY:
///   y_l <- alpha_l * x_l + y_l for all l = 1, ..., N
/// where:
///   * N is the number of vectors,
///   * x_1, ..., x_N are the N input vectors,
///   * y_1, ..., y_N are the N output vectors,
///   * alpha_1, ..., alpha_N are N scaling factors for x_1, ..., x_N.
///
/// \tparam MemberType: TeamPolicy member type
/// \tparam XViewType: Input type for X, needs to be a 1D or 2D view
/// \tparam YViewType: Input type for Y, needs to be a 1D or 2D view
/// \tparam alphaViewType: Input type for alpha, needs to be a 1D view or Scalar
///
/// \param[in] member: TeamPolicy member
/// \param[in] alpha: input coefficient for X, a rank 1 view or a scalar
/// \param[in] X: Input vector X, a rank 1 or 2 view
/// \param[in/out] Y: Output vector Y, a rank 1 or 2 view
///
/// Two nested parallel_for with both TeamThreadRange and ThreadVectorRange
/// (or one with TeamVectorRange) are used inside.
///

template <typename MemberType>
struct TeamVectorAxpy {
  template <typename XViewType, typename YViewType, typename alphaViewType>
  KOKKOS_INLINE_FUNCTION static int invoke(const MemberType &member, const alphaViewType &alpha, const XViewType &X,
                                           const YViewType &Y);
};

}  // namespace KokkosBatched

#include "KokkosBatched_Axpy_Impl.hpp"

#endif
